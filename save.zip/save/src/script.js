document.addEventListener("DOMContentLoaded", function () {

  const attendanceBox =
    document.getElementById("attendance");

  const monthInput =
    document.getElementById("month");

  const saveButton =
    document.getElementById("saveData");

  const pdfButton =
    document.getElementById("pdfButton");

  const photoInput =
    document.getElementById("workerPhoto");

  const photoPreview =
    document.getElementById("photoPreview");

  const STORAGE_KEY =
    "attendanceRegisterFinal";


  /* =========================
     CREATE ATTENDANCE TABLE
  ========================= */

  function createAttendanceTable(savedData = {}) {

    const monthValue = monthInput.value;

    if (!monthValue) {
      attendanceBox.innerHTML =
        "📅 Pehle Month select karein.";
      return;
    }

    const [year, month] =
      monthValue.split("-").map(Number);

    const daysInMonth =
      new Date(year, month, 0).getDate();

    let html = `
      <div style="overflow-x:auto;">

        <table style="
          width:100%;
          min-width:650px;
          border-collapse:collapse;
        ">

        <tr style="
          background:linear-gradient(
            135deg,
            #1976d2,
            #7b2ff7
          );
          color:white;
        ">

          <th style="padding:10px;">Date</th>
          <th>Day</th>
          <th>Status</th>
          <th>OT</th>
          <th>Leave Reason</th>

        </tr>
    `;


    for (let day = 1; day <= daysInMonth; day++) {

      const old =
        savedData[day] || {};

      const status =
        old.status || "P";

      const ot =
        old.ot ?? "0";

      const reason =
        old.reason || "";


      let statusColor =
        "#2eaf4a";

      if (status === "A")
        statusColor = "#e53935";

      if (status === "M")
        statusColor = "#f4b400";


      const date =
        new Date(
          year,
          month - 1,
          day
        );

      const dayName =
        date.toLocaleDateString(
          "en-IN",
          {
            weekday: "short"
          }
        );


      html += `

        <tr style="
          border-bottom:1px solid #ddd;
          background:white;
        ">

          <td style="
            padding:8px;
            text-align:center;
            font-weight:bold;
          ">
            ${day}
          </td>

          <td style="text-align:center;">
            ${dayName}
          </td>

          <td style="text-align:center;">

            <button
              class="statusButton"
              data-status="${status}"
              onclick="changeStatus(this)"
              style="
                width:45px;
                padding:8px;
                border:none;
                border-radius:8px;
                background:${statusColor};
                color:white;
                font-weight:bold;
              "
            >
              ${status}
            </button>

          </td>

          <td style="text-align:center;">

            <input
              type="number"
              min="0"
              step="0.5"
              value="${ot}"
              class="ot"
              style="
                width:65px;
                padding:7px;
              "
            >

          </td>

          <td>

            <input
              type="text"
              class="reason"
              placeholder="Leave reason"
              value="${reason}"
              style="
                width:130px;
                padding:7px;
                display:${
                  status === "M"
                    ? "block"
                    : "none"
                };
              "
            >

          </td>

        </tr>
      `;
    }


    html += `

        </table>
      </div>

      <button
        onclick="showSummary()"
        style="
          width:100%;
          padding:13px;
          margin-top:15px;
          border:none;
          border-radius:10px;
          background:#00a884;
          color:white;
          font-size:16px;
          font-weight:bold;
        "
      >
        📊 Monthly Summary
      </button>

      <div id="summary"></div>
    `;


    attendanceBox.innerHTML = html;
  }


  /* =========================
     STATUS P → A → M → P
  ========================= */

  window.changeStatus =
    function (button) {

      const current =
        button.dataset.status;


      if (current === "P") {

        button.dataset.status = "A";
        button.innerText = "A";
        button.style.background =
          "#e53935";

      }

      else if (current === "A") {

        button.dataset.status = "M";
        button.innerText = "M";
        button.style.background =
          "#f4b400";

      }

      else {

        button.dataset.status = "P";
        button.innerText = "P";
        button.style.background =
          "#2eaf4a";
      }


      const reason =
        button
          .closest("tr")
          .querySelector(".reason");


      if (button.dataset.status === "M") {

        reason.style.display = "block";

      } else {

        reason.style.display = "none";
        reason.value = "";
      }
    };


  /* =========================
     MONTH CHANGE
  ========================= */

  monthInput.addEventListener(
    "change",
    function () {

      createAttendanceTable();

    }
  );


  /* =========================
     PHOTO
  ========================= */

  photoInput.addEventListener(
    "change",
    function () {

      const file =
        this.files[0];

      if (!file) return;


      const reader =
        new FileReader();


      reader.onload =
        function (event) {

          photoPreview.innerHTML = `
            <img
              src="${event.target.result}"
            >
          `;

        };


      reader.readAsDataURL(file);
    }
  );


  /* =========================
     SUMMARY
  ========================= */

  window.showSummary =
    function () {

      const buttons =
        document.querySelectorAll(
          ".statusButton"
        );

      const ots =
        document.querySelectorAll(".ot");


      let present = 0;
      let absent = 0;
      let leave = 0;
      let totalOT = 0;


      buttons.forEach(
        function (button, index) {

          const status =
            button.dataset.status;


          if (status === "P")
            present++;

          if (status === "A")
            absent++;

          if (status === "M")
            leave++;


          totalOT +=
            Number(
              ots[index].value
            ) || 0;

        }
      );


      document.getElementById(
        "summary"
      ).innerHTML = `

        <div style="
          margin-top:15px;
          padding:16px;
          border-radius:14px;
          background:linear-gradient(
            135deg,
            #eef7ff,
            #f5efff
          );
          line-height:2;
        ">

          <b style="font-size:18px;">
            📊 Monthly Summary
          </b>

          <br>

          🟢 Present:
          <b>${present}</b> Days

          <br>

          🔴 Absent:
          <b>${absent}</b> Days

          <br>

          🟡 Leave:
          <b>${leave}</b> Days

          <br>

          ⏱️ Total OT:
          <b>${totalOT}</b> Hours

        </div>
      `;
    };


  /* =========================
     SAVE DATA
  ========================= */

  saveButton.addEventListener(
    "click",
    function () {

      if (!monthInput.value) {

        alert(
          "📅 Pehle Month select karein."
        );

        return;
      }


      const buttons =
        document.querySelectorAll(
          ".statusButton"
        );

      const ots =
        document.querySelectorAll(".ot");

      const reasons =
        document.querySelectorAll(
          ".reason"
        );


      const attendance = {};


      buttons.forEach(
        function (button, index) {

          attendance[index + 1] = {

            status:
              button.dataset.status,

            ot:
              ots[index].value,

            reason:
              reasons[index].value
          };

        }
      );


      const photo =
        photoPreview
          .querySelector("img")
          ?.src || "";


      const data = {

        companyName:
          document.getElementById(
            "companyName"
          ).value,

        workerName:
          document.getElementById(
            "workerName"
          ).value,

        workerAge:
          document.getElementById(
            "workerAge"
          ).value,

        workerWork:
          document.getElementById(
            "workerWork"
          ).value,

        month:
          monthInput.value,

        photo:
          photo,

        attendance:
          attendance
      };


      try {

        localStorage.setItem(
          STORAGE_KEY,
          JSON.stringify(data)
        );

        alert(
          "✅ Attendance successfully saved!"
        );

      }

      catch (error) {

        alert(
          "⚠️ Save nahi hua. Photo bahut badi ho sakti hai."
        );
      }

    }
  );


  /* =========================
     LOAD SAVED DATA
  ========================= */

  const saved =
    localStorage.getItem(
      STORAGE_KEY
    );


  if (saved) {

    try {

      const data =
        JSON.parse(saved);


      document.getElementById(
        "companyName"
      ).value =
        data.companyName || "";


      document.getElementById(
        "workerName"
      ).value =
        data.workerName || "";


      document.getElementById(
        "workerAge"
      ).value =
        data.workerAge || "";


      document.getElementById(
        "workerWork"
      ).value =
        data.workerWork || "Belder";


      monthInput.value =
        data.month || "";


      if (data.photo) {

        photoPreview.innerHTML = `
          <img src="${data.photo}">
        `;
      }


      if (data.month) {

        createAttendanceTable(
          data.attendance || {}
        );

      }

    }

    catch (error) {

      console.log(
        "Saved data load error"
      );
    }
  }


  /* =========================
     PDF
  ========================= */

  pdfButton.addEventListener(
    "click",
    function () {

      const month =
        monthInput.value;


      if (!month) {

        alert(
          "📅 Pehle Month select karein."
        );

        return;
      }


      const company =
        document.getElementById(
          "companyName"
        ).value || "Company";


      const worker =
        document.getElementById(
          "workerName"
        ).value || "Worker";


      const age =
        document.getElementById(
          "workerAge"
        ).value || "";


      const work =
        document.getElementById(
          "workerWork"
        ).value || "Belder";


      const photo =
        photoPreview
          .querySelector("img")
          ?.src || "";


      const buttons =
        document.querySelectorAll(
          ".statusButton"
        );

      const ots =
        document.querySelectorAll(".ot");

      const reasons =
        document.querySelectorAll(".reason");


      const [year, monthNumber] =
        month.split("-").map(Number);


      const daysInMonth =
        new Date(
          year,
          monthNumber,
          0
        ).getDate();


      let present = 0;
      let absent = 0;
      let leave = 0;
      let totalOT = 0;

      let rows = "";


      for (
        let day = 1;
        day <= daysInMonth;
        day++
      ) {

        const index = day - 1;

        const status =
          buttons[index]?.dataset.status
          || "P";


        const ot =
          Number(
            ots[index]?.value
          ) || 0;


        const reason =
          reasons[index]?.value
          || "";


        if (status === "P")
          present++;

        if (status === "A")
          absent++;

        if (status === "M")
          leave++;


        totalOT += ot;


        const date =
          new Date(
            year,
            monthNumber - 1,
            day
          );


        const dayName =
          date.toLocaleDateString(
            "en-IN",
            {
              weekday: "short"
            }
          );


        let color =
          "#2eaf4a";


        if (status === "A")
          color = "#e53935";

        if (status === "M")
          color = "#f4b400";


        rows += `

          <tr>

            <td>${day}</td>

            <td>${dayName}</td>

            <td style="
              background:${color};
              color:white;
              font-weight:bold;
            ">
              ${status}
            </td>

            <td>${ot}</td>

            <td>${reason}</td>

          </tr>
        `;
      }


      const printWindow =
        window.open(
          "",
          "_blank"
        );


      if (!printWindow) {

        alert(
          "⚠️ Popup blocked hai. Chrome me popup allow karein."
        );

        return;
      }


      printWindow.document.write(`

        <!DOCTYPE html>

        <html>

        <head>

          <title>
            Attendance Register
          </title>

          <style>

            body {
              font-family:Arial,sans-serif;
              padding:20px;
              color:#222;
            }

            h1 {
              text-align:center;
              color:#1976d2;
            }

            .month {
              text-align:center;
              color:#666;
              margin-bottom:20px;
            }

            .details {
              border:2px solid #1976d2;
              border-radius:12px;
              padding:15px;
              margin-bottom:20px;
              min-height:110px;
            }

            .photo {
              width:90px;
              height:90px;
              object-fit:cover;
              border-radius:10px;
              border:2px solid #1976d2;
              float:right;
            }

            table {
              width:100%;
              border-collapse:collapse;
            }

            th {
              background:#1976d2;
              color:white;
              padding:8px;
            }

            td {
              border:1px solid #ccc;
              padding:7px;
              text-align:center;
            }

            .summary {
              margin-top:20px;
              padding:15px;
              background:#eef5ff;
              border-radius:12px;
              line-height:1.8;
            }

            .signature {
              margin-top:50px;
              display:flex;
              justify-content:space-between;
            }

            .sign {
              width:180px;
              text-align:center;
              border-top:1px solid #222;
              padding-top:7px;
            }

            button {
              margin-top:20px;
              padding:12px 20px;
              background:#1976d2;
              color:white;
              border:none;
              border-radius:8px;
            }

            @media print {
              button {
                display:none;
              }
            }

          </style>

        </head>

        <body>

          <h1>
            📋 Attendance Register
          </h1>

          <div class="month">
            Month: ${month}
          </div>

          <div class="details">

            ${
              photo
              ? `<img
                   src="${photo}"
                   class="photo"
                 >`
              : ""
            }

            <b>Company:</b>
            ${company}

            <br><br>

            <b>Worker:</b>
            ${worker}

            <br><br>

            <b>Age:</b>
            ${age}

            <br><br>

            <b>Work:</b>
            ${work}

          </div>


          <table>

            <tr>
              <th>Date</th>
              <th>Day</th>
              <th>Status</th>
              <th>OT</th>
              <th>Leave Reason</th>
            </tr>

            ${rows}

          </table>


          <div class="summary">

            <h3>
              📊 Monthly Summary
            </h3>

            🟢 Present:
            <b>${present}</b> Days

            <br>

            🔴 Absent:
            <b>${absent}</b> Days

            <br>

            🟡 Leave:
            <b>${leave}</b> Days

            <br>

            ⏱️ Total OT:
            <b>${totalOT}</b> Hours

          </div>


          <div class="signature">

            <div class="sign">
              Worker Signature
            </div>

            <div class="sign">
              Manager Signature
            </div>

          </div>


          <button onclick="window.print()">
            🖨️ Print / Save PDF
          </button>

        </body>

        </html>
      `);


      printWindow.document.close();
      printWindow.focus();

    }
  );

});